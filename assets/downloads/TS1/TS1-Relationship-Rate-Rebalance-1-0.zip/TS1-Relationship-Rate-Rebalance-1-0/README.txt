============================================================
The Sims 1 - Relationship Rate Rebalance (RRR) - ArcboundX
============================================================

DESCRIPTION
------------------------------------------------------------
- A comprehensive rebalance of The Sims 1's relationship decay 
  and adjustment systems.
- Addresses the crippling relationship decay that made 
  maintaining many friendships overly burdensome.
- Comes in 2 versions: Version A (Balanced) and Version B (Relaxed).

Version: 1.0
Updated: 2026
Size: 4KB
Downloads: 0

============================================================
CORE ISSUE ADDRESSED
============================================================
- In vanilla The Sims 1, every day at 4:00 PM all non-household 
  relationships lose 2 Short Term Relationship (STR) points.
- High decay rate forces tedious social upkeep for Sims with many friends.
- STR decays even when Sims are sharing a lot, converted to LTR at an 
  unfavorable rate, punishing your Sim for socializing in public.
- Long Term Relationship (LTR) points rarely mitigated this, making 
  friendships feel unrealistic.

============================================================
UNDERSTANDING THE SYSTEMS
============================================================
- The Sims 1 has two relationship adjustment systems:

1. Daily Global Decay
   - Vanilla: -2 STR applies to ALL non-household relationships daily at 4PM.

2. On-Lot Passive System
   - Vanilla: Relationships between your Sims and non-household Sims 
     sharing your lot get adjusted every 2 hours.
   - Two paths: Path A or Path B, depending on whether STR or LTR is higher.

============================================================
CORE CHANGES
============================================================
- Global Relationship Decay Reduction
  - Daily decay halved from -2 → -1 STR for non-household Sims.

- Passive Relationship Gain/Loss Rework
  - STR ↔ LTR conversion rebalanced.
  - Checks every 4 hours to reduce punishing decay and reward long-term friendships.

- Version A: Balanced Model
  - Keeps STR/LTR exchanges fair.
  - Rewards meaningful relationships over time.
  - Occasional maintenance still required at a relaxed pace.

- Version B: Relaxed Model
  - No on-lot penalties.
  - Gradual LTR growth.
  - STR gain on Path-B reduced to prevent inflation.
  - Occasional maintenance still recommended.

============================================================
TECHNICAL IMPLEMENTATION
============================================================
- Modified VisitGenerator.iff: 2 → 1 (global decay)
- Modified HDLTR.iff: Path A/B multiple reassignments
- Check Interval: 2 → 4 Sim hours

============================================================
MATHEMATICAL COMPARISON VS VANILLA
============================================================
Metric                                   | Vanilla       | Version A (Balanced) | Version B (Relaxed)
----------------------------------------|---------------|--------------------|------------------
4PM Daily decay (all non-household)     | -2            | -1                 | -1
On-Lot STR/LTR Conversion Timer          | Every 2 hours | Every 4 hours      | Every 4 hours
PATH-A: STR > LTR Conversion             | -2 STR/+1 LTR | -1 STR/+1 LTR      | 0 STR/+1 LTR
PATH-B: LTR > STR Conversion             | +1 STR/-2 LTR | +2 STR/-1 STR      | +1 STR/0 STR
PATH-A Max Conversion/day                | -24 STR/+12 LTR | -6 STR/+6 LTR    | 0 STR/+6 LTR
PATH-B Max Conversion/day                | +24 STR/-12 LTR | +12 STR/-6 LTR   | +6 STR/0 LTR

============================================================
VERSION SELECTION GUIDE
============================================================
Choose Version A (Balanced) if:
- You want dynamic relationship mechanics with long-term trade-offs.
- Little benefit at start, larger gains later.
- Prefer a relaxed system that slowly gets easier over time.
- Flexible relationship maintenance.

Choose Version B (Relaxed) if:
- You want consistent relationship gains over time.
- Regular benefits all the time (linear progression).
- Prefer hands-off relationship management.
- Relaxed system that builds gradually.

Gameplay Implications for BOTH versions:
- Career Advancement: friend decay reduced ~50%, much more manageable.
- Long-Term Play: relationships evolve more naturally.
- Community Lots: no penalties for shared occupancy.
- Social Requirements: realistically achievable without abandoning the system.

============================================================
INSTALLATION GUIDE
============================================================
Step-by-Step:
1. Choose Version A (Balanced) or Version B (Relaxed).
2. Download the zipped mod file (both versions included).
3. Extract your chosen version into The Sims 1 installation folder:
   - The Sims/Gamedata/Objects/VisitGenerator.iff
   - The Sims/ExpansionShared/HDLTR.iff
4. Launch The Sims 1 – changes are immediate.

Note:
- Versions are mutually exclusive; install only one at a time.

Compatibility:
- Tested on The Sims 1 Complete Collection.
- Should work on Legacy Collection.
- To uninstall, delete modified IFF files.

============================================================
VERSION 1.0 (2026) - SUMMARY
============================================================
- Reduced 4PM global decay -2 → -1 STR
- Reworked on-lot passive adjustment system (2 versions)
- Version A (Balanced): Daily -1 / Lifetime +1 (STR>LTR); Daily +2 / Lifetime -1 (LTR>STR)
- Version B (Relaxed): Daily 0 / Lifetime +1 (STR>LTR); Daily +1 / Lifetime 0 (LTR>STR)
- Check interval: 2 → 4 hours

============================================================
DESIGN PHILOSOPHY AND CLOSING NOTES
============================================================
- Addresses The Sims 1's punishing relationship systems while offering meaningful choices.
- Version A: strategic STR/LTR conversion, reduced penalties.
- Version B: eliminates on-lot penalties for hands-off play.

Quote from Will Wright (The Sims creator):
"We wanted players to feel the consequences of social choices. Relationships weren’t just numbers—they reflected how Sims lived their lives and interacted with others, giving players a sense of connection and responsibility."

- Both versions make social requirements realistically achievable while preserving core mechanics.
- Versions may be tweaked or added in the future. Feedback welcome via the Contact Form.

CONTACT;
https://arcboundx.github.io/seven7th-heaven/
